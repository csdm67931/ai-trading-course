# AI 輔助交易工具課程

> 主辦單位：群益期貨
> 講師：Bob
> 課程對象：大學三年級學生
> 課程形式：電腦教室實作，共三堂，每堂 3 小時

---

## 課程目標

上完三堂課之後，同學能夠：

- 獨立使用 Gemini Gem 建立每日自動化盤勢摘要流程
- 透過 Antigravity 串接 AI 工具，建立自己的輔助工具
- 在一個月的交易競賽中，記錄並展示 AI 在交易決策中的實際角色

---

## 課程地圖

| 堂次 | 主題 | 核心工具 | 交付成果 |
|------|------|----------|----------|
| 第一堂 | AI 工具開箱與環境建置 | Gemini、Github、Antigravity | Gem 建立 + repo 建立 + 個人主題確定 |
| 第二堂 | AI 組合應用與盤勢分析 | Gemini Gem、Antigravity | 可重複使用的 AI 盤勢分析流程 |
| 第三堂 | 獨立開發與成果展示 | Antigravity、Github | 可運作的個人 AI 工具 + Demo |

---

## 如何取得課程資料

### 方法一：直接下載單一檔案（推薦新手）

1. 點進你需要的資料夾（例如 `lesson1`）
2. 點選檔案名稱
3. 右上角點「Download raw file」按鈕即可下載

### 方法二：下載整個課程資料包

點擊頁面右上角綠色「Code」按鈕 → 選「Download ZIP」，解壓縮後即可取得所有檔案。

### 方法三：git clone（有基礎者）

```bash
git clone https://github.com/（你的帳號）/ai-trading-course.git
```

---

## 課程資料夾說明

```
ai-trading-course/
├── README.md                   ← 你現在看的這份文件
├── lesson1/                    ← 第一堂課
│   ├── README.md               ← 第一堂課說明與流程
│   ├── 操作手冊_第一堂.pdf      ← 課堂操作步驟（列印版）
│   ├── 預載Prompt.txt          ← 貼入 Gemini 的完整 Prompt
│   └── antigravity_範例.json   ← Antigravity 範例工作流匯入檔
├── lesson2/                    ← 第二堂課（上課前會更新）
│   └── README.md
└── lesson3/                    ← 第三堂課（上課前會更新）
    └── README.md
```

---

## 課後競賽作業說明

課程結束後，同學需要在一個月內完成以下任務：

1. 使用課堂建立的 AI 工具輔助實際交易決策
2. 每週至少記錄一次 AI 給的建議與自己最終決策的差異
3. 競賽結束後繳交一支 3 到 5 分鐘的影片，內容包含：
   - 你的 AI 工具長什麼樣子、怎麼用
   - AI 建議與你實際決策的比較案例（至少兩個）
   - 你對「AI 在交易中的角色」的個人心得

---

## 工具清單與申辦連結

| 工具 | 用途 | 連結 |
|------|------|------|
| Gemini | AI 對話與 Gem 自動化 | https://gemini.google.com |
| Github | 存放與分享成果 | https://github.com |
| Antigravity | AI Agent 工作流串接 | https://antigravity.ai |

---

## 聯絡講師

如有課程問題，請透過課堂提供的聯絡方式詢問。
